
-- Copyright (c) 2009, Sven Kirmess

local NoRandomOculus_localization = { }

NoRandomOculus_localization.enUS = {
	OCULUS					= "The Oculus"
}

NoRandomOculus_localization.deDE = {
	OCULUS					= "The Oculus"
}

NoRandomOculus_localization.frFR = {
	OCULUS					= "The Oculus"
}

NoRandomOculus_localization.koKR = {
}

NoRandomOculus_Constants = NoRandomOculus_localization[GetLocale()]

