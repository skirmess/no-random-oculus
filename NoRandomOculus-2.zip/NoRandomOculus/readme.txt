
NoRandomOculus

Automatically extends your Oculus id whenever you login. This should make it less likely for the LFG to pick Oculus for your random daily.

*** Changelog

Version 2
 * Added support for German client

Version 1
 * Initial release

